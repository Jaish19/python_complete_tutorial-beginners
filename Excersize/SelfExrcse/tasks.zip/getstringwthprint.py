def name(case):
    print ("Thank you Mr.",case )
if __name__ == '__main__':
	userInput = str(input("Hi user!!! Please enter your name:"))
	
	name(userInput)
	
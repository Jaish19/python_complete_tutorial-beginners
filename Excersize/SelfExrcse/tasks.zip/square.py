def square(parameter):
	
	print ("The square value of your entered input is :", parameter**2)
if __name__ == '__main__':
	userInput = int(input ("User!!! Please enter your value: "))
	square(userInput)
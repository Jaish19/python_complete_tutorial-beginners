if __name__ == '__main__':
	userInput = input ("Please enter your input here: ")


	if (type(userInput) == int):
		print (float(userInput))
	elif (type(userInput) == float):
		print (int(userInput))
	else:
		print ("Its optional")
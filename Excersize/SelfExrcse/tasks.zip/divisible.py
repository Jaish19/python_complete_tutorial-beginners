# EXAMPLE PROGRAM FOR DIVISIBLE BY 2 OR 3 OR 4

# This below function for display the output

def InputfromUser(parameter):
	print ("The user entered input value is:", parameter)

# This below function for finding divisible by 2


def divisibleBy2(parameter):
	 a = userInput % 2
	 if a == 0:
	 	print ("This number is divisble by 2")
	 else:
	 	print ("This number is not divisible by 2")

# This below function for finding divisible by 3


def divisibleBy3(parameter):
	 b = userInput % 3
	 if b == 0:
	 	print ("This number is divisble by 3")
	 else:
	 	print ("This number is not divisible by 3")

# This below function for finding divisible by 4


def divisibleBy4(parameter):
	 c = userInput % 2
	 if c == 0:
	 	print ("This number is divisble by 4")
	 else:
	 	print ("This number is not divisible by 4")
	 	

'''
To get the input and operate the function, main function block is used
'''
if __name__ == '__main__':
	userInput= int(input("User!!! please enter your input:"))
	divisibleBy2(userInput)
	divisibleBy3(userInput)
	divisibleBy4(userInput)

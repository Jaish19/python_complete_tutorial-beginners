# Example coding for odd or even using function
'''
odd or even function to know whether the entered input is even or odd
'''
def oddeven(get):
	c= userInput %2
	if c == 0:
		print("The entered input is even")
	elif c==1:
		print ("The entered input is odd")

if __name__ == '__main__':
	userInput = int(input("User!!! Please enter your input to check whether its even or odd:"))
	oddeven(userInput)
class CEO(object):
	def __init__(self,a):
		self.a=a
		print("This is CEO inheritance mr.",self.a)

		pass
	def project(self):
		print("This CEO!!! I am ok with your project")

class teamLeader(CEO):

	def __init__(self,a):
		self.a=a
		print("This is team leader inheritance",self.a)
		# we are using super syntax to shift the data's from one class to another
		super(teamLeader, self).__init__(a)	
		pass

	# def project(self):
		# print("Ok Permission granted from Team Leader")

class projectLeader(teamLeader):
	def __init__(self,a):
		self.a=a
		print("This is project leader inheritance Mr.",a)
		super(projectLeader, self).__init__(a)	
		pass
	# def project(self):
		# print("yeah mister....I'll put a word to Team Leader")

class employee(projectLeader):
	def __init__(self,a):
		self.a=a
		print("Sir, I wish to take up this project by own Mr.",self.a)
		super(employee, self).__init__(a)
		
		pass


if __name__ == '__main__':
	order=employee("jai")
	order.project()
	print(employee.__mro__)

class receiverEnd(object):
    def __init__(self):
        pass
    def output(self):
        print("your decoding process will happen here")
class satelite(object):
    def __init__(self):
        pass

    def rxr(self):
        print("your data's are reached here....your process will happen soon")
        final=receiverEnd()
        final.output()
class fm(satelite):
    def __init__(self):
        print("FM signal is transmitting from Transmitter towards satelite")
        pass
class smartPhones(satelite):
    def __init__(self):
        print("Smart phone antenna starts to active")
        pass
    def encoding(self):
        print("Encoding process will begin here")

if __name__ == '__main__':
    obj1=smartPhones()
    obj1.encoding()
    obj1.rxr()
    obj2=fm()
    obj2.rxr()
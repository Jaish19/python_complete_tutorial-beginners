class mobileStation(object):
    def __init__(self,a):
        self.a=a
        print("waiting for permission for",self.a)

        pass
    def authority(self):
        print("Call Ringing.....")
    def location(self):
        print("you might be from idea user...your location will receive through text message")

class baseStation(mobileStation):
    def __init__(self,a):
        self.a=a
        print("Dear Subscriber!!!! I'll Transfer the data to Mobile station")   
        print("We are in base station...the contact no is",self.a)
        super(baseStation,self).__init__(a)
        pass
    
        
class Idea(baseStation):
    def __init__(self,a):
        self.a=a
        print("Dear user!!! your mobile no is",self.a)  
        print("Dear Idea user!!!your calling starts to connecting.....")
        super(Idea, self).__init__(a)
        pass
    
class Docomo(baseStation):
    def __init__(self,a):
        self.a=a
        print("Dear user!!! your mobile no is",self.a)
        print("Dear Docomo user!!!your calling starts to connecting.....")
        super(Docomo, self).__init__(a)
        pass
    def location(self):
        print("Location will be sent to you through text message")

if __name__ == '__main__':
    frIdea=int(input("User!!! Please enter your number:"))
    frDocomo=int(input("User!!! Please enter your number:"))
    permission=Idea(frIdea)
    permission.authority()
    permission.location()
    permission2=Docomo(frDocomo)
    
    permission2.authority()
    permission2.location()

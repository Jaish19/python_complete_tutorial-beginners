# Bank programming for account creation & withdraw & Deposit
# Create a class as bank to proceed the functions
class bank(object):
	# Function for account creation
	def account(self):
		accountName=str(input("User!!! Please enter your name:"))
		age=int(input("User!!! Please give your age:"))
		gender=str(input("User!!! Please enter your gender:"))
		print("Hi",accountName,"Gender",gender,"Age:",age)
		print("Thank you!!! Registering your account in our reputed bank...")
		jai=(accountName,age)


		return jai

	# Function for deposite 
	def deposite(self,name,age):
		print("Welcome to deposite your money Mr/Ms/Mrs",name)
		print("parameter age",age)
		print("Dear user!!! you can deposite maximum Rs.5000")
		amount=int(input("Please enter the amount:"))
		if amount<=5000:
			#amount=temp
			#return amount 
			print("Thank you!!! deposite amount Rs.",amount)
		else:
			amount=0
			print("try again")
			

 		


		#[print("Thank you!!! deposite amount Rs.",amount) if amount<=5000 else print("Pls try again!!!")]
		return amount
		# function for withdraw amount
	def withdraw(self,cash):
		print("Welcome user!!!! Enter the amount you want to withdraw:")
		wthamt = int(input("User!!!Please enter the amount you wanna withdraw:"))
		[print("Please collect your cash amount Rs.",wthamt) if wthamt<=cash else print("Please enter the valid amount")]
		print("Remaining balance in your account is Rs.",cash-wthamt)
# class creation for only do the deposite function
class depositealone(object):

	def uniqdeposite(self,name):
		print("Hi!!! Mr/Mrs/Ms.",name)
		print("Dear user!!! you can deposite maximum Rs.5000")
		amount=int(input("Please enter the amount:"))
		if amount<=5000:
			#amount=temp
			#return amount 
			print("Thank you!!! deposite amount Rs.",amount)
		else:
			amount=0
			print("try again")
# class creation for only do the withdraw function
class withdrawalone(object):

	def uniqwithdraw(self,name):
		print("Dear User!!!! SBI Welcomes you....")
		print("Hi!!! Mr./Mrs./Ms.",name)
		wthamt = int(input("User!!!Please enter the amount you wanna withdraw:"))
		print("Please collect your cash amount Rs.",wthamt)

		




if __name__ == '__main__':

	sbi=bank()
	dep=depositealone()
	wdr=withdrawalone()
	print("Welcome to SBI:\n1.Account Details \n2.Deposite \n3.Withdraw")
	option=int(input("Dear user!!! Please select the option:"))
	if option == 1:
		jai=sbi.account()
		print("Name",jai)
		cash = sbi.deposite(jai[0],jai[1])
		print("cash",cash)
		sbi.withdraw(cash)
	elif option == 2:
		print("Dear User!!! SBI welcomes you...")
		nme=str(input("Dear User!!! Please enter your name:"))

		dep.uniqdeposite(nme)
	elif option == 3:
		print("Dear User!!! SBI welcomes you...")
		nme=str(input("Dear User!!! Please enter your name:"))
		wdr.uniqwithdraw(nme)	
		
	else:
		print("Sorry!!!You entered the wrong input")





	
	
	#print("Age:",age)
	
	
	
	




	
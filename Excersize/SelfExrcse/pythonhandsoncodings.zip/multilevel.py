 class CEO(object):
	def __init__(self):
		pass
	def project(self):
		print("This CEO!!! I am ok with your project")

class teamLeader(CEO):
	def __init__(self):
		pass
	def project(self):
		print("Ok Permission granted from Team Leader")

class projectLeader(teamLeader):
	def __init__(self):
		pass
	# def project(self):
		# print("yeah mister....I'll put a word to Team Leader")

class employee(projectLeader):
	def __init__(self):
		print("Sir, I wish to take up this project by own")
		pass


if __name__ == '__main__':
	order=employee()
	order.project()
	print(employee.__mro__)